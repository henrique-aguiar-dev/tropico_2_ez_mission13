# Tropico 2 - Pirate Cove EZ mod
Tropico 2 Pirate Cove campaign: Mission: A New War made easier

Changes made:
- A major difficulty in this mission is the lack of captives. A "shipwrecked mariners" event has been included in the mission which occasionally gives you 4 to 8 free captives.
- The cost of recruiting captains was reduced by 50%, from $2000 to $1000.

1. Download the .7z file;
2. Extract to game directory
   Steam version = :\Program Files (x86)\Steam\steamapps\common\Tropico\Maps
   CD version = :\Program Files\Tropico2\Maps
3. It will ask you to replace the original "Episode13.txt" file. If you want, make a backup, then replace it.
